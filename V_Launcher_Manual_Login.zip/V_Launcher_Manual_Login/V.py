import os, json, base64, ctypes
from ctypes import wintypes
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox

APP_NAME = "V"
ROOT = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "VLauncher")
DATA_FILE = os.path.join(ROOT, "accounts.json")
PROFILES_DIR = os.path.join(ROOT, "chrome_profiles")
os.makedirs(ROOT, exist_ok=True)
os.makedirs(PROFILES_DIR, exist_ok=True)

class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]

def dpapi(data: bytes, decrypt=False) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Credential encryption is supported on Windows only.")
    crypt = ctypes.windll.crypt32
    kernel = ctypes.windll.kernel32
    raw = ctypes.create_string_buffer(data, len(data))
    in_blob = DATA_BLOB(len(data), ctypes.cast(raw, ctypes.POINTER(ctypes.c_ubyte)))
    out_blob = DATA_BLOB()
    if decrypt:
        ok = crypt.CryptUnprotectData(ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob))
    else:
        ok = crypt.CryptProtectData(ctypes.byref(in_blob), "V Launcher credentials", None, None, None, 0, ctypes.byref(out_blob))
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel.LocalFree(out_blob.pbData)

def load_accounts():
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            rows = json.load(f)
        out = []
        for row in rows:
            try:
                raw = dpapi(base64.b64decode(row["secret"]), True).decode("utf-8")
                user, pw = raw.split("\n", 1)
                out.append({"username": user, "password": pw})
            except Exception:
                continue
        return out
    except Exception:
        return []

def save_accounts(accounts):
    rows = []
    for a in accounts:
        enc = dpapi((a["username"] + "\n" + a["password"]).encode("utf-8"))
        rows.append({"secret": base64.b64encode(enc).decode("ascii")})
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(rows, f)
    os.replace(tmp, DATA_FILE)

def find_chrome():
    candidates = [
        os.path.join(os.environ.get("PROGRAMFILES", r"C:\Program Files"), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", "Chrome", "Application", "chrome.exe"),
    ]
    for path in candidates:
        if path and os.path.isfile(path):
            return path
    return None

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("V")
        self.root.geometry("680x500")
        self.root.minsize(600, 420)
        self.accounts = load_accounts()
        self._build()
        self.refresh()

    def _build(self):
        frame = ttk.Frame(self.root, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="V — Roblox Manual Session Launcher", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Save accounts as username:password. Login is always manual in Chrome.").pack(anchor="w", pady=(3, 10))

        entry_row = ttk.Frame(frame)
        entry_row.pack(fill="x", pady=(0, 8))
        self.entry = ttk.Entry(entry_row)
        self.entry.pack(side="left", fill="x", expand=True)
        self.entry.bind("<Return>", lambda event: self.add_account())
        ttk.Button(entry_row, text="Add account", command=self.add_account).pack(side="left", padx=(8, 0))

        self.tree = ttk.Treeview(frame, columns=("username", "status"), show="headings", selectmode="extended", height=13)
        self.tree.heading("username", text="Username")
        self.tree.heading("status", text="Status")
        self.tree.column("username", width=260)
        self.tree.column("status", width=300)
        self.tree.pack(fill="both", expand=True)

        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="Open manual login", command=self.open_selected).pack(side="left")
        ttk.Button(buttons, text="Delete selected", command=self.delete_selected).pack(side="left", padx=8)
        ttk.Button(buttons, text="Select all", command=lambda: self.tree.selection_set(self.tree.get_children())).pack(side="left")
        ttk.Button(buttons, text="Clear selection", command=lambda: self.tree.selection_remove(self.tree.selection())).pack(side="left", padx=8)

        self.status = tk.StringVar(value="Ready")
        ttk.Label(frame, textvariable=self.status, relief="sunken", anchor="w").pack(fill="x", pady=(10, 0))
        ttk.Label(frame, text="V does not fill or submit the login form. Complete login, CAPTCHA, or 2FA yourself.").pack(anchor="w", pady=(6, 0))

    def refresh(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for i, account in enumerate(self.accounts):
            self.tree.insert("", "end", iid=str(i), values=(account["username"], "Saved"))

    def add_account(self):
        value = self.entry.get().strip()
        if ":" not in value:
            messagebox.showerror("Invalid format", "Use username:password")
            return
        username, password = value.split(":", 1)
        if not username or not password:
            messagebox.showerror("Invalid format", "Username and password cannot be empty.")
            return
        if any(a["username"].casefold() == username.casefold() for a in self.accounts):
            messagebox.showinfo("Duplicate account", "That username is already saved.")
            return
        self.accounts.append({"username": username, "password": password})
        try:
            save_accounts(self.accounts)
        except Exception as exc:
            self.accounts.pop()
            messagebox.showerror("Save failed", str(exc))
            return
        self.entry.delete(0, "end")
        self.refresh()
        self.status.set("Account saved. Login will be manual.")

    def delete_selected(self):
        indexes = sorted((int(x) for x in self.tree.selection()), reverse=True)
        if not indexes:
            return
        if not messagebox.askyesno("Delete accounts", "Delete selected saved accounts? Chrome profile folders are kept."):
            return
        for index in indexes:
            self.accounts.pop(index)
        save_accounts(self.accounts)
        self.refresh()
        self.status.set("Selected accounts deleted.")

    def open_selected(self):
        indexes = [int(x) for x in self.tree.selection()]
        if not indexes:
            messagebox.showinfo("Select accounts", "Select one or more account rows first.")
            return
        chrome = find_chrome()
        if not chrome:
            messagebox.showerror("Chrome not found", "Install Google Chrome, then restart V.")
            return
        for index in indexes:
            account = self.accounts[index]
            # Use a dedicated persistent Chrome profile per account.
            safe_name = "".join(c if c.isalnum() or c in "-_." else "_" for c in account["username"])
            profile = os.path.join(PROFILES_DIR, safe_name)
            os.makedirs(profile, exist_ok=True)
            try:
                subprocess.Popen([
                    chrome,
                    f"--user-data-dir={profile}",
                    "--no-first-run",
                    "--no-default-browser-check",
                    "https://www.roblox.com/login"
                ])
            except Exception as exc:
                messagebox.showerror("Chrome launch failed", str(exc))
                return
        self.status.set(f"Opened {len(indexes)} Chrome profile(s). Enter credentials and log in manually.")

def main():
    if os.name != "nt":
        print("V Launcher is designed for Windows.")
        return
    root = tk.Tk()
    App(root)
    root.mainloop()

if __name__ == "__main__":
    main()
