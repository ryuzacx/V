@echo off
cd /d "%~dp0"
py V.py
if errorlevel 1 pause
