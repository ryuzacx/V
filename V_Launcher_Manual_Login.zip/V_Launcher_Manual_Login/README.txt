V Launcher — Manual Login edition

This edition never fills in or submits Roblox credentials. It opens a dedicated, persistent Chrome profile for each saved username at the Roblox login page so you can log in manually and handle CAPTCHA/2FA yourself.

Setup:
1. Install Python 3.11+ on Windows (enable Add Python to PATH).
2. Run Install-Dependencies.bat.
3. Run Run-V.bat.
4. Add accounts one at a time using username:password.
5. Select account rows and click Open manual login.
6. Log in manually in each Chrome window. The profile is persistent, so Chrome may retain the session cookies.

Build an EXE:
Run Build-V.exe.bat. Output: dist\V.exe

Security:
- Credentials are encrypted with Windows DPAPI for the current Windows user.
- The app does not bypass CAPTCHA or 2FA.
- Do not share the saved account database or leave your Windows session unlocked.
- Chrome profiles are stored in %LOCALAPPDATA%\VLauncher\chrome_profiles.
