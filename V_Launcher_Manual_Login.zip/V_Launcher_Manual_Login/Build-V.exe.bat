@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
py -m PyInstaller --noconfirm --clean --onefile --windowed --name V V.py
if errorlevel 1 (
  echo Build failed. Check the messages above.
  pause
  exit /b 1
)
echo Done: dist\V.exe
pause
